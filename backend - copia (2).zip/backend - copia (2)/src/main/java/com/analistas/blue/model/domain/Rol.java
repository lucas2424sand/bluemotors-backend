package com.analistas.blue.model.domain;

public enum Rol {
    ADMIN, VENDEDOR, CLIENTE
}

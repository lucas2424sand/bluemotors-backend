package com.analistas.blue.model.domain;

public enum EstadoServicio {
    PENDIENTE,
    EN_PROCESO,
    FINALIZADO,
    CANCELADO
}

package com.analistas.blue.model.domain;

public enum EstadoOrden {
    PENDIENTE_PAGO,
    COMPROBANTE_SUBIDO,
    PAGADA,
    RECHAZADA
}

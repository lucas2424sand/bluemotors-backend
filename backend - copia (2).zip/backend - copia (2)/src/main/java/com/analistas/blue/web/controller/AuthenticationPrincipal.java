package com.analistas.blue.web.controller;

public @interface AuthenticationPrincipal {

}

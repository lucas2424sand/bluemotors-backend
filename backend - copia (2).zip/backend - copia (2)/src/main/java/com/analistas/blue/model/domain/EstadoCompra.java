package com.analistas.blue.model.domain;

public enum EstadoCompra {
    PENDIENTE_PAGO,
    PAGADA,
    CANCELADA
}
